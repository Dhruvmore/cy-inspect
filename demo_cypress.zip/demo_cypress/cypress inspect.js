describe('gems essence home page testing', () => {
    it('verify the url', () => {
      cy.visit('https://www.gemsessence.com/')
         cy.title('Gems Essence')
         cy.title('Infotech Pvt. Ltd')
      });
      it('verify the place holder of name  in form', () => {
        cy.visit('https://www.gemsessence.com/')
        cy.get('#candidate_name').invoke('attr', 'placeholder').should('contain', 'Full Name')    
     });
     it('verify the place holder  of email in form', () => {
        cy.visit('https://www.gemsessence.com/')
        cy.get('#candidate_email').invoke('attr', 'placeholder').should('contain', 'Email')    
     });
     it('verify the place holder of number  in form', () => {
        cy.visit('https://www.gemsessence.com/')
        cy.get('#candidate_contact_number').invoke('attr', 'placeholder').should('contain', 'Contact Number With Country Code')    
     });
     it('verify the place holder of subject in form', () => {
        cy.visit('https://www.gemsessence.com/')
        cy.get('#candidate_subject').invoke('attr', 'placeholder').should('contain', 'Subject')    
     });
     it('verify the place holder of message in form', () => {
        cy.visit('https://www.gemsessence.com/')
        cy.get('#candidate_message').invoke('attr', 'placeholder').should('contain', 'Message')    
    
     });
     it('verify the name field', () => {
        cy.visit('https://www.gemsessence.com/')
        cy.get('#candidate_name').type('dhruv').clear().type('Dhruv more')  
    
     });
     it('verify the email field', () => {
        cy.visit('https://www.gemsessence.com/')
        cy.get('#candidate_email').type('dhruvmor1997@gmail.com').clear().type('Dhruvmor@gmail.com')  
    
     });
     it('verify the contact field', () => {
        cy.visit('https://www.gemsessence.com/')
        cy.get('#candidate_contact_number').type('8827026944').clear().type('883703844')  
    
     });
     it('verify the subject field', () => {
        cy.visit('https://www.gemsessence.com/')
        cy.get('#candidate_subject').type('asdvajgsjabgakjdiu').clear().type('asjgaugsuags')  
    
     });
     it('verify the message field', () => {
        cy.visit('https://www.gemsessence.com/')
        cy.get('#candidate_message').type('asdvajgsjabgakjdiu').clear().type('asjgaugsuags')  
    
     });
     it('verify the browser botton', () => {
        cy.visit('https://www.gemsessence.com/')
        cy.get('.custom-file-input').click() 
    
     });
     it('verify the browser botton', () => {
        cy.visit('https://www.gemsessence.com/')
        cy.get('.btn-default').click() 
    
     });
  
     it('verify the browser botton', () => {
        cy.visit('https://www.gemsessence.com/')
        cy.get('.btn-primary').click() 
    
     });
     it('verify the hiring page', () => {
        cy.visit('https://www.gemsessence.com/hire_our_developer/')
        cy.title('Hire Our Developer')
    
     });
     it('verify the project quotation form', () => {
      cy.visit('https://www.gemsessence.com/hire_our_developer/')
      cy.title('Project Quotation')
  
   });
   it('verify the name field', () => {
      cy.visit('https://www.gemsessence.com/hire_our_developer/')
      cy.get('#contact_us_name').type('dhruv more')
  
   });
   
   it('verify the contact field', () => {
      cy.visit('https://www.gemsessence.com/hire_our_developer/')
      cy.get('#contact_us_phone_number').type('8827026944')
  
   });
   it('verify the project description  field', () => {
      cy.visit('https://www.gemsessence.com/hire_our_developer/')
      cy.get('#contact_us_project_description').type('ashaibs hasguahs hagsha ahsgu8a')
  
   });
  
     
   it('Test Case6', function (){
      //file to be uploaded path in project folder
      const p = 'Picture.png'
      // launch URL
      cy.visit("https://www.gemsessence.com/hire_our_developer")
      //upload file with attachFile
      cy.get('#inputGroupFile01').attachFile(p)
      //click on upload
     // cy.get('#file-submit').click()
      //verify uploaded file
      cy.get('#inputGroupFile01').contains('Picture.png')
   });

   it('verify the project description  field', () => {
      cy.visit('https://www.gemsessence.com/hire_our_developer/')
      cy.get('.btn-default').click()
  
   });

   it('verify the career page ', () => {
      cy.visit('https://www.gemsessence.com/career')
      cy.url().should('eq', 'https://www.gemsessence.com/career')
  
   });
   it('verify the career page ', () => {
      cy.visit('https://www.gemsessence.com/career')
      cy.get('.wc-title').find('h1').contains('Career')
      
  
   });
   it('verify the career page ', () => {
      cy.visit('https://www.gemsessence.com/hire_our_developer')
      cy.get('.wc-title').find('h1').contains('Hire Our Developer')
      });


      it('verify the career page ', () => {
         cy.visit('https://www.gemsessence.com/career')
         cy.get('.scrollable-area').find('h3').contains('Why Join Us')
         
     
      });
      it('verify the submit resume form name filed ', () => {
         cy.visit('https://www.gemsessence.com/career')
         cy.get('#candidate_name').type('dhruv')
         
     
      });
      it('verify the Email filed ', () => {
         cy.visit('https://www.gemsessence.com/career')
         cy.get('#candidate_email').type('dhruv@gmail.com')
      });
      it('verify the contact filed ', () => {
         cy.visit('https://www.gemsessence.com/career')
         cy.get('#candidate_contact_number').type('7728273633')
      });
      it('verify the subject filed ', () => {
         cy.visit('https://www.gemsessence.com/career')
         cy.get('#candidate_subject').type(' subject to assined')
      });
      it('verify the message filed ', () => {
         cy.visit('https://www.gemsessence.com/career')
         cy.get('#candidate_message').type(' subject to assined gasuhabu havsua hgsua hagsua hsuab hygvusa hvsu')
      });
      it('Test Case6', function (){
         //file to be uploaded path in project folder
         const p = 'Picture.png'
         // launch URL
         cy.visit("https://www.gemsessence.com/career")
         //upload file with attachFile
         cy.get('#inputGroupFile01').attachFile(p)
         //click on upload
        // cy.get('#file-submit').click()
         //verify uploaded file
         cy.get('#inputGroupFile01').contains('Picture.png')
      });
      it('verify the submit ', () => {
         cy.visit('https://www.gemsessence.com/career')
         cy.get('.btn-default').click()
     
      });
      it('verify the tabels ', () => {
         cy.visit('https://www.gemsessence.com/career')
         cy.get('.facility-points mb-0')
      });
      it('verify the career page ', () => {
         cy.visit('https://www.gemsessence.com/career')
         cy.get('.apply-job-slide').find('h4').contains('Looking for ROR Job?')
         
     
      });
      it('verify the career page ', () => {
         cy.visit('https://www.gemsessence.com/career')
         cy.get('.justify-content-center coming-soon').find('h3').contains('Comming soon...')
         
     
      });
      it('verify the lower heading ', () => {
         cy.visit('https://www.gemsessence.com/career')
         cy.get('.ftr-brand').find('h4').contains('Gems Essence')
         cy.get('.ftr-brand').find('h4').contains(' Infotech Pvt. Ltd')
     
      });
      it('verify the lower heading ', () => {
         cy.visit('https://www.gemsessence.com/career')
         cy.get('.ftr-follow').find('h5').contains('follow us on')
        
     
      });
      it('verify the lower heading ', () => {
         cy.visit('https://www.gemsessence.com/career')
        cy.get('body > div.app > footer > div.container.container-xl > div > div:nth-child(2) > div > div.col-xl-4.col-md-4 > div > ul > li:nth-child(1) > a').click()
     
      });
      it('verify the contact heading ', () => {
         cy.visit('https://www.gemsessence.com/career')
         cy.get('.ftr-ico-content').contains('0731-4969817')
        
     
      });
   });
   it('verify the url ', () => {
      cy.visit('https://www.gemsessence.com/contact_us')
   });
   it('verify the contact us form name field ', () => {
      cy.visit('https://www.gemsessence.com/contact_us')
      cy.get('#contact_us_name').type('dhruv')
   });
   it('verify the contact us form email field ', () => {
      cy.visit('https://www.gemsessence.com/contact_us')
      cy.get('#contact_us_email').type('dhruv@gmail.com')
   });
   it('verify the contact us form contact no field ', () => {
      cy.visit('https://www.gemsessence.com/contact_us')
      cy.get('#contact_us_phone_number').type('8827026944')
   });
   it('verify the contact us form subject field ', () => {
      cy.visit('https://www.gemsessence.com/contact_us')
      cy.get('#contact_us_subject').type('hiiidajbc ahcabcb')
   });
   it('verify the contact us form message field ', () => {
      cy.visit('https://www.gemsessence.com/contact_us')
      cy.get('#contact_us_message').type('hiiidajbc ahcabcb')
   });
   it('verify the contact us form message field ', () => {
      cy.visit('https://www.gemsessence.com/contact_us')
      cy.get('.btn-default').click()
   });
   it('verify the contact us page ', () => {
      cy.visit('https://www.gemsessence.com/contact_us')
      cy.get('.contact-us-banner').find('h4').contains('Committed to delight you')
     });
      it('verify the contact us page ', () => {
      cy.visit('https://www.gemsessence.com/contact_us')
     cy.get('#contact-tab').should('be.visible')

   });
   it('verify the contact us page ', () => {
      cy.visit('https://www.gemsessence.com/contact_us')
      cy.get('.btn-default').should('be.visible').and('be.enabled')
   });
      it('verify the contact us page ', () => {
         cy.visit('https://www.gemsessence.com/contact_us')
         cy.get('.btn-default').contains('Subscribe')
   
      });
      it('verify the contact us form message field ', () => {
         cy.visit('https://www.gemsessence.com/contact_us')
         cy.get('.btn-default').dblclick()
      });
      it('verify the services  page ', () => {
         cy.visit('https://www.gemsessence.com/services')
      
      });
   
      it('verify the services page url ', () => {
         cy.visit('https://www.gemsessence.com/services')
         cy.url().should('eq', 'https://www.gemsessence.com/services')
     
      });
      it('verify the services page tittle ', () => {
         cy.visit('https://www.gemsessence.com/services')
         cy.get('.wc-title').find('h1').contains('Services')
        
     
      });
      it('verify the services page hower buton', () => {
         cy.visit('https://www.gemsessence.com/services')
         cy.get('.navbar-toggler').click()
        
     
      });
      it('verify the services page images ', () => {
         cy.visit('https://www.gemsessence.com/services')
         cy.get('.container-xl').find('img').should('be.visible')
        
     
      });
      it('verify the services page tittle ', () => {
         cy.visit('https://www.gemsessence.com/services')
         cy.get('.technologies-wrapper').find('h3').contains('We are Using')
        
     
      });
      it('verify the services page lower tittle ', () => {
         cy.visit('https://www.gemsessence.com/services')
         cy.get('.technologies-wrapper').find('h4').contains('tools and technologies')
        
     
      });
      it.only('verify the services page images ', () => {
         cy.visit('https://www.gemsessence.com/services')
         cy.get('#hireOurDeveloperImg').click()
      });